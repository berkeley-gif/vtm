angular.module( 'vtm.about', [
  'ui.router',
  'placeholders'
])

.config(function config( $stateProvider ) {
  $stateProvider.state( 'about', {
    url: '/about',
    views: {
      "": {
        controller: 'AboutCtrl',
        templateUrl: 'about/about.tpl.html'
      },
      "overview@about": {
        templateUrl: 'about/about.overview.tpl.html'
      }
    },
    data:{ pageTitle: 'Learn More' }
  })

  ;
})

.controller( 'AboutCtrl', function AboutCtrl( $scope ) {

})

;
